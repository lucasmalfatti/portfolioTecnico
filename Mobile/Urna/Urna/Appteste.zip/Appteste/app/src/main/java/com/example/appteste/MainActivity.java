package com.example.appteste;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.time.LocalDateTime;

public class MainActivity extends AppCompatActivity {
    EditText login, senha;
    String l;
    int s;
    String mensagem = "Logado";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
       senha = findViewById(R.id.senha);
       login = findViewById(R.id.login);
    }

    public void cadastro(View v) {
        Toast.makeText(this, "Usuario Cadastrado", Toast.LENGTH_SHORT).show();
        String m = login.getText().toString();
        int l = Integer.parseInt(senha.getText().toString());
        Usuario usu = new Usuario(m,l);
        usu.salvarU();
    }
    public void print (String msg){
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
    public void verifica_usuario(View v){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Usuario");
        reference.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot d : snapshot.getChildren()){
                    l = login.getText().toString();
                    s = Integer.parseInt(senha.getText().toString());
                    if (d.getValue(Usuario.class).getLogin().equals(l) && d.getValue(Usuario.class).getSenha() == s){
                        Usuario u = d.getValue(Usuario.class);
                        mensagem = u.getLogin() + "Existe";
                        print(mensagem);
                        break;
                    }else{
                        mensagem = " Usuario não existe";
                        print(mensagem);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void logar(View v) {
        l = login.getText().toString();
        s = 0;
        try{
            s = Integer.parseInt(senha.getText().toString());
        }catch(Exception e){
            mensagem = "Usuario inexistente!";
        }
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.child("Usuario").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dn : snapshot.getChildren()) {
                    Usuario u = dn.getValue(Usuario.class);
                    if (u.getLogin().equals(l)&&u.getSenha()==s){
                        mensagem = "Logado";
                        TelaPagamento.user = u;
                        Intent i = new Intent(MainActivity.this, Tela2.class);
                        startActivity(i);
                        break;
                    }
                    else{
                        mensagem = "Preencha corretamente!";
                    }
                }
                Toast.makeText(MainActivity.this, mensagem, Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });


    }
    public void cadastrar(View v) {
        Toast.makeText(this, "Se Cadastre!", Toast.LENGTH_SHORT).show();
        Intent i = new Intent(this, TelaCadastro.class);
        startActivity(i);
    }
    public void retornaDiaAtual(View v){
        int hora = LocalDateTime.now().getHour();
        int minuto = LocalDateTime.now().getMinute();
        String dia = LocalDateTime.now().getDayOfWeek().toString();
        Toast.makeText(this, dia+" "+hora+":"+minuto, Toast.LENGTH_SHORT).show();
    }
}
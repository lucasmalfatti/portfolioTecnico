package com.example.appteste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class TelaProdutos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_produtos);
        getSupportActionBar().hide();
    }

    public void mudaTela(View v) {
        Intent i = new Intent(this, TelaPagamento.class);
        startActivity(i);
    }

    public void Avancar21(View v) {
        Intent b = new Intent(this, TelaPagamento.class);
        TelaPagamento.preco += 21;
        startActivity(b);
    }

    public void Avancar46(View v) {
        Intent b = new Intent(this, TelaPagamento.class);
        TelaPagamento.preco += 46;
        startActivity(b);
    }
    public void Avancar100(View v) {
        Intent b = new Intent(this, TelaPagamento.class);
        TelaPagamento.preco += 100;
        startActivity(b);
    }
    public void Avancar16(View v) {
        Intent b = new Intent(this, TelaPagamento.class);
        TelaPagamento.preco += 16;
        startActivity(b);
    }
}

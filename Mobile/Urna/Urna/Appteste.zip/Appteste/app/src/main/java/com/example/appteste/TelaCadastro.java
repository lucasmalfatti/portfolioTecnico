package com.example.appteste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class TelaCadastro extends AppCompatActivity {
    EditText login, senha;
    String mensagem = "Logado!";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);
        getSupportActionBar().hide();
        login=findViewById(R.id.novologin);
        senha=findViewById(R.id.novasenha);

    }public void mudaTelaCadastro(View v) {
        Toast.makeText(this, "Usuario Cadastrado", Toast.LENGTH_SHORT).show();
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
    public void avancaCadastro(View v) {
        String l = login.getText().toString();
        String s = senha.getText().toString();
        if (!TextUtils.isEmpty(l) && !TextUtils.isEmpty(s)) {
            int senhalogin_int = Integer.parseInt(senha.getText().toString());
            Usuario u = new Usuario(l,senhalogin_int);
            u.salvarU();
            mudaTelaCadastro(v);
        } else {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
        }
    }

    public void voltaTela(View v) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}
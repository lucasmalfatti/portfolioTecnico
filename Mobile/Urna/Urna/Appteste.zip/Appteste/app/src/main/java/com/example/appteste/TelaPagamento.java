package com.example.appteste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDateTime;

public class TelaPagamento extends AppCompatActivity {
    static int preco;
    static int hora = 0;
    static Usuario user;

    TextView precoFinal;
    ImageView dinheiro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_pagamento);
        getSupportActionBar().hide();
        precoFinal = findViewById(R.id.precofinal);
        precoFinal.setText(preco + "");
        dinheiro = findViewById(R.id.dinheiro);
    }

    public void pix(View v) {
        Intent b = new Intent(this, TelaPix.class);
        startActivity(b);
    }
    public void cartao(View v){
        Intent b = new Intent(this, TelaCartao.class);
        startActivity(b);
    }
    public void resetar(View v) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
    public void MudaTelaReserva (View v) {
        Reserva reserva = new Reserva();
        reserva.setDia(LocalDateTime.now().getDayOfWeek().toString());
        if(hora != 0){
            reserva.setHora(hora);
        }
        reserva.setUser(user);
        reserva.salvarR();


        Intent i = new Intent(this, TelaResultado.class);
        startActivity(i);
    }

}
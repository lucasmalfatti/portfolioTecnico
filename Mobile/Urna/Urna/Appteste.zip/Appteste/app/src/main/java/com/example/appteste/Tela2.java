package com.example.appteste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Tela2 extends AppCompatActivity {

    TextView corte30, sobrancelha10, barba15, cortebarba40, cortesobra35, barbasobra20;
    //int valor

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);
        getSupportActionBar().hide();
        corte30 = findViewById(R.id.corte);
        sobrancelha10 = findViewById(R.id.sb);
        barba15 = findViewById(R.id.bb);
        cortebarba40 = findViewById(R.id.cb);
        cortesobra35 = findViewById(R.id.cs);
        barbasobra20 = findViewById(R.id.bs);
    }
    public void Avancar30(View v) {
        Toast.makeText(this, "Bem-vindo aos barbeiros", Toast.LENGTH_SHORT).show();
        Intent b = new Intent(this, Tela3.class);
        TelaPagamento.preco = 30;
        startActivity(b);
    }
    public void Avancar10(View v) {
        Toast.makeText(this, "Bem-vindo aos barbeiros", Toast.LENGTH_SHORT).show();
        Intent b = new Intent(this, Tela3.class);
        TelaPagamento.preco = 15;
        startActivity(b);
    }
    public void Avancar15(View v) {
        Toast.makeText(this, "Bem-vindo aos barbeiros", Toast.LENGTH_SHORT).show();
        Intent b = new Intent(this, Tela3.class);
        TelaPagamento.preco = 15;
        startActivity(b);
    }
    public void Avancar40(View v) {
        Toast.makeText(this, "Bem-vindo aos barbeiros", Toast.LENGTH_SHORT).show();
        Intent b = new Intent(this, Tela3.class);
        TelaPagamento.preco = 40;
        startActivity(b);
    }
    public void Avancar35(View v) {
        Toast.makeText(this, "Bem-vindo aos barbeiros", Toast.LENGTH_SHORT).show();
        Intent b = new Intent(this, Tela3.class);
        TelaPagamento.preco = 35;
        startActivity(b);
    }
    public void Avancar20(View v) {
        Toast.makeText(this, "Bem-vindo aos barbeiros", Toast.LENGTH_SHORT).show();
        Intent b = new Intent(this, Tela3.class);
        TelaPagamento.preco = 20;
        startActivity(b);
    }
}


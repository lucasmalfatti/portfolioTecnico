package com.example.appteste;

import static com.example.appteste.TelaPagamento.user;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.time.LocalDateTime;

public class TelaCartao extends AppCompatActivity {
    EditText nome, cartao, dia, ano, csv;
    static int hora = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cartao);
        getSupportActionBar().hide();
        nome = findViewById(R.id.nome);
        cartao = findViewById(R.id.cartao);
        dia = findViewById(R.id.dia);
        ano = findViewById(R.id.ano);
        csv = findViewById(R.id.csv);
    }

    public void MudaTelaReserva (View v) {
        Reserva reserva = new Reserva();
        reserva.setDia(LocalDateTime.now().getDayOfWeek().toString());
        if(hora != 0){
            reserva.setHora(hora);
        }
        reserva.setUser(user);
        reserva.salvarR();


        Intent i = new Intent(this, TelaResultado.class);
        startActivity(i);
    }
}



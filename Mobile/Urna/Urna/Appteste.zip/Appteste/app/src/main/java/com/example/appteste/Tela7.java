package com.example.appteste;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

import java.time.LocalDateTime;

public class Tela7 extends AppCompatActivity {
    static public CheckBox h7, h8, h9, h10, h11, h12, h13, h14, h15, h16;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela7);
        getSupportActionBar().hide();
        h7 = findViewById(R.id.checkBox35);
        h8 = findViewById(R.id.checkBox39);
        h9 = findViewById(R.id.checkBox31);
        h10 = findViewById(R.id.checkBox32);
        h11 = findViewById(R.id.checkBox37);
        h12 = findViewById(R.id.checkBox36);
        h13 = findViewById(R.id.checkBox34);
        h14 = findViewById(R.id.checkBox33);
        h15 = findViewById(R.id.checkBox38);
        h16 = findViewById(R.id.checkBox40);
    }

    public void mudaTelaPreco(View v) {
        Intent i = new Intent(this, TelaProdutos.class);

        if(h7.isChecked()){
            TelaPagamento.hora = 7;

        }

        if(h8.isChecked()){
            TelaPagamento.hora = 8;
        }

        if(h9.isChecked()){
            TelaPagamento.hora = 9;
        }

        if(h10.isChecked()){
            TelaPagamento.hora = 10;
        }

        if(h11.isChecked()){
            TelaPagamento.hora = 11;
        }

        if(h12.isChecked()){
            TelaPagamento.hora = 12;
        }

        if(h13.isChecked()){
            TelaPagamento.hora = 13;
        }

        if(h14.isChecked()){
            TelaPagamento.hora = 14;
        }

        if(h15.isChecked()){
            TelaPagamento.hora = 15;
        }

        if(h16.isChecked()){
            TelaPagamento.hora = 16;
        }

        startActivity(i);
    }
}
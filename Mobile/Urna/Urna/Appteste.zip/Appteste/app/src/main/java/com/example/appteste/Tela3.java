package com.example.appteste;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Tela3 extends AppCompatActivity {
    TextView casimiro, boca, iran, mohammed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela3);
        getSupportActionBar().hide();
        casimiro = findViewById(R.id.casimiro);
        boca = findViewById(R.id.boca);
        iran = findViewById(R.id.iran);
        mohammed = findViewById(R.id.mohammed);

    }

    public void casimiro(View v) {
        Intent b = new Intent(this, Tela4.class);
        startActivity(b);


    }

    public void boca09(View v) {
        Intent b = new Intent(this, Tela5.class);
        startActivity(b);
    }

    public void iran (View v) {
        Intent b = new Intent(this, Tela6.class);
        startActivity(b);
    }

    public void mohhamed (View v) {
        Intent b = new Intent(this, Tela7.class);
        startActivity(b);
    }
}
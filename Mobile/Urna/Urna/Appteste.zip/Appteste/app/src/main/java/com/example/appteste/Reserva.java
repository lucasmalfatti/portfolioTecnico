package com.example.appteste;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Reserva {
    String dia;
    int hora;
    Usuario user;
    String barbeiro;

    public Reserva(String dia, int hora, String barbeiro) {
        this.dia = dia;
        this.hora = hora;
        this.barbeiro = barbeiro;
    }

    public Reserva() {
    }

    public String getBarbeiro() {
        return barbeiro;
    }

    public void setBarbeiro(String barbeiro) {
        this.barbeiro = barbeiro;
    }

    public Usuario getUser() {
        return user;
    }

    public void setUser(Usuario user) {
        this.user = user;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public int getHora() {
        return hora;
    }

    public void setHora(int hora) {
        this.hora = hora;
    }
    public void salvarR(){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
        reference.child("Reserva").child(user.getLogin()).setValue(this);
    }
}
